
import java.util.*;


public class conta_part {
public LinkedList c_chain;
public String c_str;

conta_part(LinkedList ll1,String sstr){
	c_chain = ll1;
	c_str = sstr;
}

}



