#ifndef _para_h
#define _para_h
#define INDENT 1		/* Extra indent makes para */
#define GAP 2			/* Empty line makes para */
#define UC 4			/* 1st word at least 2 letters UC makes para */

#endif /* _para_h */
