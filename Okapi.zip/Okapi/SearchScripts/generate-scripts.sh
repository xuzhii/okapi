#!/bin/bash

source /home/okapi/environmentSettings.bshrc

cd ${OKAPI_ROOT}/input

v_name=`ls *.exch | head -1 | cut -d'.' -f1`

echo "Generating: run-${v_name}.sh"
touch ${OKAPI_SCRIPTS}/run-${v_name}.sh
echo "#!/bin/bash" >> ${OKAPI_SCRIPTS}/run-${v_name}.sh
echo "source /home/okapi/environmentSettings.bshrc" >> ${OKAPI_SCRIPTS}/run-${v_name}.sh
echo "cd \$OKAPI_BINDIR" >> ${OKAPI_SCRIPTS}/run-${v_name}.sh
echo "./convert_runtime ${v_name} < /home/okapi/input/${v_name}.exch" >> ${OKAPI_SCRIPTS}/run-${v_name}.sh
echo "./ix1 -mem 500 -delfinal -doclens ${v_name} 0 | ./ixf ${v_name} 0" >> ${OKAPI_SCRIPTS}/run-${v_name}.sh
echo "cd \$OKAPI_JAVABIN" >> ${OKAPI_SCRIPTS}/run-${v_name}.sh
echo "java searching" >> ${OKAPI_SCRIPTS}/run-${v_name}.sh



echo "Generating: ${v_name} in databases"
touch ${BSS_PARMPATH}/${v_name}
echo "name=${v_name}" >> ${BSS_PARMPATH}/${v_name}
echo "lastbibvol=0" >> ${BSS_PARMPATH}/${v_name}
echo "bib_basename=trec.${v_name}0.bib" >> ${BSS_PARMPATH}/${v_name}
echo "bib_dir=/home/okapi/bibfiles/" >> ${BSS_PARMPATH}/${v_name}
echo "bibsize=1200" >> ${BSS_PARMPATH}/${v_name}
echo "real_bibsize=80255" >> ${BSS_PARMPATH}/${v_name}
echo "display_name=trec.${v_name}" >> ${BSS_PARMPATH}/${v_name}
echo "explanation=trec.${v_name}" >> ${BSS_PARMPATH}/${v_name}
echo "nr=1000" >> ${BSS_PARMPATH}/${v_name}
echo "nf=2" >> ${BSS_PARMPATH}/${v_name}
echo "f_abbrev=DN" >> ${BSS_PARMPATH}/${v_name}
echo "f_abbrev=TI" >> ${BSS_PARMPATH}/${v_name}
echo "rec_mult=4" >> ${BSS_PARMPATH}/${v_name}
echo "db_type=ai" >> ${BSS_PARMPATH}/${v_name}
echo "has_lims=0" >> ${BSS_PARMPATH}/${v_name}
echo "maxreclen=1980" >> ${BSS_PARMPATH}/${v_name}
echo "ni=1" >> ${BSS_PARMPATH}/${v_name}
echo "last_ixvol=0" >> ${BSS_PARMPATH}/${v_name}
echo "ix_stem=/home/okapi/bibfiles/${v_name}" >> ${BSS_PARMPATH}/${v_name}
echo "ix_volsize=1200" >> ${BSS_PARMPATH}/${v_name}
echo "ix_type=13" >> ${BSS_PARMPATH}/${v_name}
echo "no_drl=0" >> ${BSS_PARMPATH}/${v_name}


echo "Generating: ${v_name}.search_groups in databases"
touch ${BSS_PARMPATH}/${v_name}.search_groups
echo "kw 1 0 words3 psstem gsl.lemur1 1 0 2 0 -1" >> ${BSS_PARMPATH}/${v_name}.search_groups

echo "Generating: db_avail in databases"
echo "${v_name} *" >> ${BSS_PARMPATH}/db_avail



