
#define HILO 0
#define HAVE_LL
#define LL_TYPE long long
#define LARGEFILES
#define _FILE_OFFSET_BITS 64
#define HAVE_MADVISE
#define HAVE_MMAP_ZERO
#define O_BINARY 0
#define D_C "/"
#define SLASH_CHAR '/'
#define OFFSET_TYPE off_t
#define DIR_ADDR_TYPE off_t

#include <unistd.h>
#include <sys/time.h>
