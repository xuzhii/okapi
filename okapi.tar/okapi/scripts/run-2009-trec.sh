java ssearch 09article kw dn 09article.txt 0.25 100 10 1 09article.txt
